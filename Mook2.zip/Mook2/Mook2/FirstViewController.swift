//
//  FirstViewController.swift
//  RatingsApp
//
//  Created by Cody Hall on 10/15/18.
//  Copyright © 2018 marshallCIT413. All rights reserved.
//
import UIKit
import WebKit

class FirstViewController: UIViewController, WKNavigationDelegate{
    
    @IBOutlet var backButton1: UIButton!
    @IBOutlet var forwardButton1: UIButton!
    @IBOutlet var webView1: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView1.navigationDelegate = self
      
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let url = URL(string: "https://www.imdb.com/search")!
        let request = URLRequest(url: url)
        webView1.load(request)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func backButtonPush(_ sender: Any) {
        if webView1.canGoBack {
            webView1.goBack()
        }
        
    }
    
    @IBAction func forwardButtonPush(_ sender: Any) {
        if webView1.canGoForward{
            webView1.goForward()
        }
        
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        backButton1.isEnabled = webView1.canGoBack
        forwardButton1.isEnabled = webView1.canGoForward
        
        
    }
    
    
}


