//
//  secondviewcontroller.swift
//  Mook2
//
//  Created by Cody Hall on 12/3/18.
//  Copyright © 2018 marshallCIT413. All rights reserved.
//

import Foundation
